docker-compose start

http://localhost:8080

exploreradmin
exploreradminpw