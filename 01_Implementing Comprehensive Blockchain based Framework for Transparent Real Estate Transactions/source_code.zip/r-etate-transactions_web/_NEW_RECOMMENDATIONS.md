X show uid and name to user while choosing buyer
X accept reject btn for sub reg
X create user on seperate page
X show buyer and seller in toApprove table

X loader
X Success and fail modal/alert
otp verification
districtwise land
payment portal
X reject for regi
X delete requests
X show requsted estate, handle removing in cc (can store in Mongo)
? Show history in more details

set expected price
Block user from requesting

Servey no. not unique, use ULPIN